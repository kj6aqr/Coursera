library(UsingR)
library(caret)
library(gbm)
library(AppliedPredictiveModeling)
library(scales)
library(e1071)
library(randomForest)

set.seed(3433)
data(AlzheimerDisease)

adData = data.frame(diagnosis,predictors)
inTrain = createDataPartition(adData$diagnosis, p = 0.2)[[1]]
training = adData[ inTrain,]
testing = adData[-inTrain,]
ctrl <- trainControl(method="cv")

shinyServer(
  function(input, output) {
    
    selModel<-reactive({
      if(input$model == '0') {
        modFit<-NULL
      } else if(input$model == '1') {
        modFit <- train(diagnosis ~ ., data=training, method="rf", trControl=ctrl, number=3)
      } else if (input$model == '2') {
        modFit <- train(diagnosis ~ ., data=training, method="lda", trControl=ctrl)
      } else if (input$model == '3') {
        modFit <- train(diagnosis ~ ., data=training, method="gbm", trControl=ctrl)
      }
      testPred <- predict(modFit, newdata=testing)
      confusionMatrix(testPred, testing$diagnosis)
    })
    
    output$ffp <- renderPlot({  
      if(input$model != '0') {
        ctable <- as.table(matrix(c(selModel()$table), nrow = 2, byrow = TRUE)) 
        fourfoldplot(ctable, color = c("#CC6666", "#99CC99"), conf.level = 0, margin = 1, main = "Confusion Matrix")
      }
    })
    
    output$accuracy <- renderText({
      if(input$model != '0') {
        paste("Overall accuracy = ",percent(selModel()$overall['Accuracy']))
      }
    })
    
  }
)