shinyUI(pageWithSidebar(
  headerPanel("Analysis of Cognitive Impairment"),
  sidebarPanel(
    h4("Introduction"),
    p("This tool compares the efficacy of three different machine learning algorithms on a single classification problem.  This classification attempts to predict cognitive impairment from Alzheimer's disease based on several factors such as age, gender and genetic background."),
    selectInput("model","Select model:",choices=c('Please select a model'='0','   Random Forest'='1','   Linear Discriminant Analysis'='2','   Gradient Boosted Tree'='3')),
    textOutput("accuracy")
      ),
  mainPanel(
    plotOutput('ffp')
  )
))