---
title       : Test title
subtitle    : subtest subtitle
author      : Andrew
job         : me
framework   : shower        # {io2012, html5slides, shower, dzslides, ...}
highlighter : highlight.js  # {highlight.js, prettify, highlight}
hitheme     : tomorrow      # 
widgets     : []            # {mathjax, quiz, bootstrap}
mode        : selfcontained # {standalone, draft}
knit        : slidify::knit2slides
---

## Read-And-Delete

1. Edit YAML front matter
2. Write using R Markdown
3. Use an empty line followed by three dashes to separate slides!

--- .class #id 

## Slide 2

Test slide 2


```
## Error in eval(expr, envir, enclos): object 'y' not found
```

```
## Error in summary(fit): object 'fit' not found
```

---

## Slide 3


```r
x<-4
print(x)
```

---

## Slide 4


```r
print(x)
```

```
## [1] 4
```
